export class CreateUrlDto {
  id: number;
  originalUrl: string;
  shortUrl: string;
}
